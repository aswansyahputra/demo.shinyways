#' fetch_data 
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
fetch_data <- function(creds) {
  # res <- NULL
  # if (isTRUE(creds)) {
  #   res <- palmerpenguins::penguins
  # }
  # return(res)
}